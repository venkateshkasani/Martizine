from tkinter import *
import tkinter
from tkinter import filedialog
from tkinter.filedialog import askopenfilename
from tkinter import simpledialog

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')
import seaborn as sns 
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.utils import resample
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score

import os, joblib

import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Flatten
from imblearn.over_sampling import SMOTE


main=tkinter.Tk()
main.title("A Deep Learning Approach to Classifying Anemia Using Automated Blood Image Analysis")
main.geometry('8000x4000')
main.config(bg='skyblue3')
title = tkinter.Label(main, text="A Deep Learning Approach to Classifying Anemia Using Automated Blood Image Analysis",justify='center')
title.grid(column=0, row=0)
font=('times',15, 'bold')
title.config(bg='pale goldenrod', fg='black')
title.config(font=font)
title.config(height=3,width=100)
title.place(x=50,y=5)


global filename
global df 
global x,y,X_train,X_test,y_train,y_test,predict
global le,scaler
global test 

global model_file

def upload():
    global filename
    global df 
    filename = filedialog.askopenfilename()
    df=pd.read_csv(filename)
    text.insert(tkinter.END,filename+'loaded\n\n')
    text.insert(tkinter.END,str(df.shape))
    text.insert(tkinter.END,str(df))
    
def preprocessing():
    global df
    le=LabelEncoder()
    df['Anaemic']=le.fit_transform(df['Anaemic'])
    df['Sex'] = le.fit_transform(df['Sex'])
    
    
    number_of_samples=500
    df=resample(df, replace=True, n_samples=number_of_samples, random_state=30)
    #print(df.duplicated())
    text.insert(tkinter.END,'\n\n-------Preprocessing-----\n\n')
    text.insert(tkinter.END,str(df))
    category_order = ['Yes','No']
    plt.figure(figsize=(10, 6))
    ax = sns.countplot(x= df['Anaemic'])
    plt.xlabel('System Status')
    ax.set_xticklabels(category_order)
    plt.ylabel('Count')
    plt.title('Count of Anaemic')
    for p in ax.patches:
        ax.annotate(f'{p.get_height()}', (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center', fontsize=10, color='black', xytext=(0, 5),
                    textcoords='offset points')
    plt.show()
    
    
def splitting():
    global df,scaler
    global x,y,X_train,X_test,y_train,y_test,predict
  
    x = df.drop(columns=['Anaemic'], axis=1).values

    y=df['Anaemic'].values
    
    X_train,X_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=45)
    text.insert(tkinter.END,'\n\n-------Splitting-----\n\n')
    text.insert(tkinter.END,"X-train"+str(X_train.shape)+ ", Y-train"+str(y_train.shape)) 
    text.insert(tkinter.END,"\n\n X-test"+str(X_test.shape)+ ", Y-test"+str(y_test.shape))
    
    
labels=['Yes','No']
precision = []
recall = []
fscore = []
accuracy = []
def calculateMetrics(algorithm, predict, testY):
    global labels
    testY = testY.astype('int')
    predict = predict.astype('int')
    p = precision_score(testY, predict,average='macro') * 100
    r = recall_score(testY, predict,average='macro') * 100
    f = f1_score(testY, predict,average='macro') * 100
    a = accuracy_score(testY,predict)*100
    accuracy.append(a)
    precision.append(p)
    recall.append(r)
    fscore.append(f)
    print(algorithm+' Accuracy    : '+str(a))
    print(algorithm+' Precision   : '+str(p))
    print(algorithm+' Recall      : '+str(r))
    print(algorithm+' FSCORE      : '+str(f))
    report=classification_report(predict, testY,target_names=labels)
    print('\n',algorithm+" classification report\n",report)
    text.insert(tkinter.END,'\n\n-----'+algorithm+'-------\n\n')   
    text.insert(tkinter.END,algorithm + ' Accuracy:   ' + str(a)+'\n\n')
    text.insert(tkinter.END,algorithm + ' Precision:  ' + str(p)+'\n\n')
    text.insert(tkinter.END,algorithm + ' Recall:     ' + str(r)+'\n\n')
    text.insert(tkinter.END,algorithm+ '  FSCORE:     ' + str(f)+'\n\n')
    conf_matrix = confusion_matrix(testY, predict) 
    plt.figure(figsize =(5, 5)) 
    ax = sns.heatmap(conf_matrix, xticklabels = labels, yticklabels = labels, annot = True, cmap="Blues" ,fmt ="g");
    ax.set_ylim([0,len(labels)])
    plt.title(algorithm+" Confusion matrix") 
    plt.ylabel('True class') 
    plt.xlabel('Predicted class') 
    plt.show()
    

def GBC():
    global X_train, X_test, y_train, y_test   
    if os.path.exists('model/GradientBoostingClassifier.pkl'):
    #load the model:
        GBC=joblib.load('model/GradientBoostingClassifier.pkl')
        print('model loaded successfully')
        predict=GBC.predict(X_test)
        calculateMetrics("GradientBoostingClassifier",predict,y_test)
    else:
    #train the model:
        GBC=GradientBoostingClassifier(
        loss='deviance',
        learning_rate=0.0001,
        n_estimators=2,
        subsample=1.0,
        criterion='friedman_mse',
        min_samples_split=4,
        min_samples_leaf=2,
        min_weight_fraction_leaf=0.1,
        max_depth=3,
        min_impurity_decrease=5.0,
        init=None,
        random_state=0,
        max_features=2,
        verbose=0,
        max_leaf_nodes=None,
        warm_start=False,
        validation_fraction=0.1,
        n_iter_no_change=None,
        tol=0.0001,
        ccp_alpha=0.0,)
        GBC.fit(X_train,y_train)
    #saving model:
        joblib.dump(GBC,'model/GradientBoostingClassifier.pkl')
        print('model saved successfully')
        predict=GBC.predict(X_test)
        calculateMetrics("GradientBoostingClassifier",predict,y_test)
        
def DNN():
    global dnn_model, DTClassifier, X_train, X_test, y_train, y_test
    global predict, sc

    # Standardize the input features
    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # Define file paths for models
    dnn_model_Path = 'model/DNN_Regressor.h5'
    DTClassifier_Path = 'model/DTClassifier.pkl'

    # Check if pre-trained models exist
    if os.path.exists(dnn_model_Path) and os.path.exists(DTClassifier_Path):
        # Load the trained DNN model
        dnn_model = load_model(dnn_model_Path)
        print("DNN model loaded successfully.")

        # Get features from DNN for RFR training
        X_train_features = dnn_model.predict(X_train)
        X_test_features = dnn_model.predict(X_test)

        # Load the trained RFR model
        DTClassifier = joblib.load(DTClassifier_Path)
        print("DNN model loaded successfully.")

        # Make predictions
        predictions = DTClassifier.predict(X_test_features)
        print('Random Forest Regressor model predicted:', predictions)
        print('y_test output:', y_test)
        calculateMetrics("DNN Model", predictions, y_test)

    else:
        # Build and train the DNN model if not already trained
        dnn_model = Sequential()
        dnn_model.add(Dense(128, activation='relu', input_shape=(X_train.shape[1],)))
        dnn_model.add(Dense(64, activation='relu'))
        dnn_model.add(Dense(64, activation='relu'))
        dnn_model.add(Dense(32, activation='relu'))
        dnn_model.add(Dense(3, activation='softmax'))
        # Compile the DNN model
        dnn_model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

        dnn_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

        # Save the trained DNN model to a file
        dnn_model.save(dnn_model_Path)
        print("DNN  model saved successfully.")

        X_train_features = dnn_model.predict(X_train)
        X_test_features = dnn_model.predict(X_test)

        DTClassifier = DecisionTreeClassifier()
        DTClassifier.fit(X_train_features, y_train)

        # Save the trained RFR model to a file
        joblib.dump(DTClassifier, DTClassifier_Path)
        print("DNN model saved successfully.")

        # Make predictions
        predictions = DTClassifier.predict(X_test_features)
        print('DNN model predicted:', predictions)
        print('y_test output:', y_test)
        calculateMetrics("DNN DTClassifier", predictions, y_test)

         
def predict():
    global sc, DTClassifier, dnn_model, labels, scaler
    
    file = filedialog.askopenfilename(initialdir="Datasets")
    test = pd.read_csv(file)
    
    text.delete('1.0', END)
    text.insert(END, f'{file} Loaded\n')
    text.insert(END, "\n\nLoaded test data: \n" + str(test) + "\n")

    test_values = test.values
    
    test_scaled = sc.transform(test_values)
    
    dnn_predictions = dnn_model.predict(test_scaled)
    
    rfc_predictions = DTClassifier.predict(dnn_predictions)

    predicted_labels = [labels[p] for p in rfc_predictions]
    
    test['Predicted'] = predicted_labels
    
    text.insert(END, "\n\nModel Predicted value in test data: \n" + str(test) + "\n")

def graph():
    columns = ["Algorithm Name", "Accuracy", "Precision", "Recall", "f1-score"]
    algorithm_names = ["Gradient Boosting Classifier", "DNN Model"]
    
    # Combine metrics into a DataFrame
    values = []
    for i in range(len(algorithm_names)):
        values.append([algorithm_names[i], accuracy[i], precision[i], recall[i], fscore[i]])
    
    temp = pd.DataFrame(values, columns=columns)
    text.delete('1.0', END)
    # Insert the DataFrame in the text console
    text.insert(END, "All Model Performance metrics:\n")
    text.insert(END, str(temp) + "\n")
    
    # Plotting the performance metrics
    metrics = ["Accuracy", "Precision", "Recall", "f1-score"]
    index = np.arange(len(algorithm_names))  # Positions of the bars

    # Set up the figure and axes
    fig, ax = plt.subplots(figsize=(10, 6))
    bar_width = 0.2  # Width of the bars
    opacity = 0.8

    # Plotting each metric with an offset
    plt.bar(index, accuracy, bar_width, alpha=opacity, color='b', label='Accuracy')
    plt.bar(index + bar_width, precision, bar_width, alpha=opacity, color='g', label='Precision')
    plt.bar(index + 2 * bar_width, recall, bar_width, alpha=opacity, color='r', label='Recall')
    plt.bar(index + 3 * bar_width, fscore, bar_width, alpha=opacity, color='y', label='f1-score')

    # Labeling the chart
    plt.xlabel('Algorithm')
    plt.ylabel('Scores')
    plt.title('Performance Comparison of All Models')
    plt.xticks(index + bar_width, algorithm_names)  # Setting the labels for x-axis (algorithms)
    plt.legend()

    # Display the plot
    plt.tight_layout()
    plt.show()
         
def close():
  main.destroy()
  
font=('times', 15, 'bold')
uploadButton = Button(main, text="Upload Dataset",command=upload)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=100)
uploadButton.config(font=font)

uploadButton = Button(main, text="pre Processing ",command=preprocessing)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=170)
uploadButton.config(font=font)



uploadButton = Button(main, text="Splitting",command=splitting)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=240)
uploadButton.config(font=font)


uploadButton = Button(main, text="GradientBoosting",command=GBC)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=310)
uploadButton.config(font=font)

uploadButton = Button(main, text="DNN",command=DNN)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=380)
uploadButton.config(font=font)

uploadButton = Button(main, text="Graph",command=graph)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=450)
uploadButton.config(font=font)

uploadButton = Button(main, text="Predict",command=predict)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=520)
uploadButton.config(font=font)

uploadButton = Button(main, text="Close",command=close)
uploadButton.config(bg='pale green', fg='Black',width=14)
uploadButton.place(x=50,y=590)
uploadButton.config(font=font)

font1 = ('times', 12, 'bold')
text=Text(main,height=25,width=120)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=290,y=100)
text.config(font=font1)

main.mainloop()
    
    